﻿# clean up and check script written for Pyranet
# this is a bootstrap script that downloads the latest version
# See readme file for version history and known issues.
#Requires -Version 4
#Requires -RunAsAdministrator

cls
#create c:\pyranetmaint if not exist
Write-Host "Checking download folder exists"
If(!(test-path c:\pyranetmaint))
{
      New-Item -ItemType Directory -Force -Path c:\pyranetmaint | Out-Null
}

#clear download folder of old script files
Get-ChildItem -Path c:\pyranetmaint -Include * -File -Recurse -Force | foreach { $_.Delete()}

#downloads payload from http url
Write-Host "Downloading script files"
Invoke-WebRequest -Uri "https://s3.eu-central-1.wasabisys.com/maintvisit/checks.zip" -OutFile "c:\pyranetmaint\checks.zip"

#extracts zip file overwriting old files
Write-Host "Extracting Files"

Add-Type -A System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory('c:\pyranetmaint\checks.zip', 'c:\pyranetmaint')

#move the reboot.bat file to c:\scripts
If(!(test-path c:\scripts))
{
      New-Item -ItemType Directory -Force -Path c:\scripts | Out-Null
}
Move-Item -Path c:\pyranetmaint\reboot.bat -Destination c:\scripts\reboot.bat -Force

#starts downloaded scriptfile
Write-Host "Starting Maintenance Script..."
Invoke-Expression -Command "C:\pyranetmaint\checks.ps1 nocls"