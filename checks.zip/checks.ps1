# clean up and check script written for Pyranet
# v0.9.5 Jan 2022
#See readme file for version history and known issues.
#Requires -Version 4
#Requires -RunAsAdministrator
param ($nocls)

If (!($nocls))
{
Clear-Host
}

# set variables for output folder and files
Write-Host "Setting up Variables and output"

$outpath = "C:\pyranetmaint\checksoutput\" #folder output will be saved to
$domainadmin = "domainadmins" #domain admins list
$entadmin ="entadmins" #enterprise admins list
$schemaadmin = "schemaadmin" #schema admins list
$userlist ="users" #user list
$adlevel = "adlevel.txt" #ad and forest level
$dcdiag ="dcdiag.txt" # dcdiag output
$repadmin = "repadmin.txt" #repadmin output
$stamp = Get-Date -F yyyy-MM-dd
$servername = hostname
$destination = $outpath + "zz_output.zip"
$importfolder = $PSScriptRoot + "\{4DE83BF8-C295-4758-BABB-70B3D978675A}" #GPO import folder

If(Test-path $destination) {Remove-item $destination}

# check for the output path and create if not found
If(!(test-path $outpath))
{
      New-Item -ItemType Directory -Force -Path $outpath | Out-Null
}
Write-Host "Files will be saved in" $outpath -ForegroundColor 'Green'

# cleanup output folder
Get-ChildItem -Path $outpath -Include * -File -Recurse -Force | ForEach-Object { $_.Delete()}

# disable error notifications
$ErrorActionPreference = 'SilentlyContinue'

Write-Host "Clearing common Temp files folders..."

#checks for and deletes files in c:\windows\temp
If((test-path c:\windows\temp))
{
      Get-ChildItem -Path c:\windows\temp -Include * -File -Recurse -Force | ForEach-Object { $_.Delete()}
}
#checks for and deletes files in c:\temp
If((test-path c:\temp))
{
      Get-ChildItem -Path c:\temp -Include * -File -Recurse -Force | ForEach-Object { $_.Delete()}
}

#checks for and deletes *.mdmp crash files in c:\ProgramData\AVAST
If((test-path c:\ProgramData\AVAST))
{
      Get-ChildItem -Path c:\ProgramData\AVAST -Include *.mdmp -File -Recurse -Force | ForEach-Object { $_.Delete()}
}

#checks for and clears c:\sagebackups
If((Test-Path c:\SageBackups))
{
    Get-ChildItem -Path "C:\SageBackups" -Recurse | Where-Object {($_.LastWriteTime -lt (Get-Date).AddDays(-7))} | Remove-Item -Recurse -Force
}

#stops windows update and cleans up the SoftwareDistribution folder
Write-Host "Clearing WU Software Distribution folder..."

# check the .old folder does not exist and remove if found
Add-Type -AssemblyName PresentationCore,PresentationFramework
	
$ButtonType = [System.Windows.MessageBoxButton]::YesNo
$MessageboxTitle = "Confirm Winupdate Cleanup"
$Messageboxbody = "Proceed with Winupdate cleanup?"
$MessageIcon = [System.Windows.MessageBoxImage]::Error
$msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

switch  ($msgBoxInput) {

'Yes' {
        Write-Host "cleaning up update store"
        If((test-path C:\Windows\SoftwareDistribution.old))
        {
              Remove-Item -Path C:\Windows\SoftwareDistribution.old -Recurse
        }
        #stop service and clean up, rename and remove to get the service up and running faster, as if folder is large the delete can take some time
        Get-Service -Name wuauserv | Stop-Service
        Rename-Item -Path "c:\windows\SoftwareDistribution" -NewName "SoftwareDistribution.old"
        Get-Service -Name wuauserv | Start-Service
        Remove-Item -Path C:\Windows\SoftwareDistribution.old -Recurse
    }
'No' {Write-Host "Cleanup skipped"}

}


# cleanup WinSxS

    Add-Type -AssemblyName PresentationCore,PresentationFramework
	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm WinSxS Cleanup"
    $Messageboxbody = "Proceed with WinSxS cleanup - this can take some time?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

  switch  ($msgBoxInput) {

  'Yes' {
			Write-Host "Checking and cleaning up component store"
			dism.exe /online /Cleanup-Image /AnalyzeComponentStore
			dism.exe /online /Cleanup-Image /StartComponentCleanup
		}
  'No' {Write-Host "Cleanup skipped"}

}



# Check for speculative execution side-channel vulnerabilities
If(!(Test-Path $PSScriptRoot\SpeculationControl.psd1) -or !(Test-Path $PSScriptRoot\SpeculationControl.psm1) )
{
Write-Host "Module files missing, please copy and re-run script" -ForegroundColor 'Red'
}
Else
{
Write-Host "Checking for speculative execution side-channel vulnerabilities"
$SaveExecutionPolicy = Get-ExecutionPolicy
Set-ExecutionPolicy RemoteSigned -Scope Currentuser
Write-Host "Importing Module"
Import-Module c:\pyranetmaint\SpeculationControl.psd1
Write-Host "Running Checks..."
Get-SpeculationControlSettings *> ($outpath + "spec.txt")
Write-Host "Please make sure to check for issues and plan for resolving" -ForegroundColor 'Red'
Set-ExecutionPolicy $SaveExecutionPolicy -Scope Currentuser
}

#Check for and remove Pulseway

Write-Host "Checking for pulseway reg key..."
If (Test-Path 'HKLM:\SOFTWARE\MMSOFT Design')
 {
    Write-Host "Pulseway registry key found, starting uninstall..." -ForegroundColor 'Red'
    $result = gwmi win32_product -filter "Name LIKE 'Pulseway'" | Select-Object IdentifyingNumber;
    [string] $a = $result.identifyingNumber;
    msiexec.exe /X $a /qn
    Remove-Item -Path "HKLM:\SOFTWARE\MMSOFT Design" -Recurse
    Write-Host "Pulseway uninstallation completed"
 }
Else {Write-Host "Pulseway reg key not found"}
Write-Host "Checking for Pulseway Scheduled Task"
if ($(Get-ScheduledTask -TaskName "PulsewayServiceCheck" -ErrorAction SilentlyContinue).TaskName -eq "PulsewayServiceCheck") {
    Unregister-ScheduledTask -TaskName "PulsewayServiceCheck" -Confirm:$False
    Write-Host "Pulseway Task found; removing..." -ForegroundColor 'Red'
} 
Else {Write-Host "Pulseway Task not found"}
Write-Host "Checking for Pulseway service..."
$servicename = "PC Monitor"
If ((Get-Service $servicename))
    {
    Write-Host "Pulseway service found, stopping and removing service" -ForegroundColor 'Red'
    Stop-Service $servicename
    Set-Service $servicename -StartupType Disabled
    sc.exe delete "PC Monitor"
    }
Else {Write-Host "Pulseway service not found"}


#Check for and remove ShadowControl

Write-Host "Checking for ShadowControl..."
$servicename = "stc_endpt_svc"
If ((Get-Service $servicename))
    {
    Write-Host "ShadowControl service found" -ForegroundColor 'Red'
    Add-Type -AssemblyName PresentationCore,PresentationFramework
	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm removal"
    $Messageboxbody = "ShadowControl found. Remove?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

    switch  ($msgBoxInput) {

         'Yes' {
            $result = gwmi win32_product -filter "Name LIKE 'StorageCraft ShadowControl'" | Select-Object IdentifyingNumber;
            [string] $a = $result.identifyingNumber;
            msiexec.exe /X $a /qn
            Write-Host "ShadowControl uninstallation completed"
         }
        'No' {Write-Host "Removal skipped"}

    }
    }
Else {Write-Host "ShadowControl service not found"}

#Check for hyper-v and list VM's and replication status
# Get the Hyper-V feature and store it in $hyperv
Write-Host "checking for Hyper-V."
$hyperv = Get-WindowsOptionalFeature -FeatureName Microsoft-Hyper-V -Online

# Check if Hyper-V is enabled and output status.
Start-Sleep -Second 10 #needed for the feature check to come back correctly.
if($hyperv.State -eq 'Enabled') {
    
    Write-Host "Hyper-V is enabled."
    Write-Host "listing VMs."
    Get-VM | Out-Host
    Get-VM | Out-File -FilePath ($outpath + "vmlist.txt")
    Write-Host "Checking replication."
    Get-VMReplication | Out-Host
    Get-VMReplication | Out-File -FilePath ($outpath + "vmreplication.txt")
    Write-Host "Checking intergration service."
	Get-VM | Get-VMIntegrationService | Where-Object {$_.SecondaryOperationalStatus -eq 'ProtocolMismatch'} | Out-Host
    Get-VM | Get-VMIntegrationService | Where-Object {$_.SecondaryOperationalStatus -eq 'ProtocolMismatch'} | Out-File -FilePath ($outpath + "vmintergrations.txt")

} else {
    Write-Host "Hyper-V is disabled."
}

#check windows defender

Write-Host "checking for defender"
$defender = Get-WindowsOptionalFeature -FeatureName Windows-Defender -Online

if($defender.State -eq 'Enabled')
{
    Add-Type -AssemblyName PresentationCore,PresentationFramework
	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm removal"
    $Messageboxbody = "Windows Defender found. Remove?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

  switch  ($msgBoxInput) {

  'Yes' {Uninstall-WindowsFeature -Name Windows-Defender}
  'No' {Write-Host "Removal skipped"}

}
}
Else
{
Write-Host "Defender not found" -ForegroundColor 'Green'
}

#check power plan

Write-Host "Checking power plan"
get-ciminstance -N root\cimv2\power -Class win32_PowerPlan | Select-Object ElementName,IsActive | Format-Table -a

Try {
        $HighPerf = powercfg -l | ForEach-Object{if($_.contains("High performance")) {$_.split()[3]}}
        $CurrPlan = $(powercfg -getactivescheme).split()[3]
        if ($CurrPlan -ne $HighPerf)
            {
                Add-Type -AssemblyName PresentationCore,PresentationFramework	
                $ButtonType = [System.Windows.MessageBoxButton]::YesNo
                $MessageboxTitle = "Confirm profile change"
                $Messageboxbody = "Change power profile to high?"
                $MessageIcon = [System.Windows.MessageBoxImage]::Error
                $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

              switch  ($msgBoxInput) {
              'Yes' {
              powercfg -setactive $HighPerf
              Write-Host "Power profile changed" -ForegroundColor 'Cyan'
              }
              'No' {Write-Host "change of power profile skipped"}
              }
            }
         
    } Catch {Write-Warning -Message "Unable to set power plan to high performance"}

#Defrag windows search DB if dound

Write-Host "Checking for Windows Search..."
If ((test-path C:\ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb))
    {
    $freespace = (Get-PSDrive C).Free
    $searchsize = (Get-Item C:\ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb).length
        if ($freespace -gt $searchsize)
        {
            Write-Host "Windows Search index found" -ForegroundColor 'Red'
            $searchstate = (Get-Service 'wsearch').StartType
            Set-Service -Name wsearch -StartupType Disabled
            Get-Service -Name wsearch | Stop-Service
            Start-Sleep -Second 10
            Write-Host "Defraging the search index"
            esentutl.exe /d C:\ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb /T C:\pyranetmaint\temp.edb
            Set-Service -Name wsearch -StartupType $searchstate
            Get-Service -Name wsearch | Start-Service
        }
        Else
        {
            Write-Host "Not enough space to defrag. Please resolve manually" -ForegroundColor 'Red'
        }

    }
Else {Write-Host "Windows Search index not found"}

#add firewall to allow inbound ping

Write-Host "Checking if inbound PING firewall rule enabled"
$ruleenabled = get-netfirewallrule -DisplayName "File and Printer Sharing (Echo Request - ICMPv4-In)"
if($ruleenabled.Enabled -eq 'True' )
{
    Write-Host "Rule is already enabled"
}
Else
{
    Add-Type -AssemblyName PresentationCore,PresentationFramework	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm firewall change"
    $Messageboxbody = "Allow inbound PING rule?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

    switch  ($msgBoxInput) {
    'Yes' {
        Write-Host "Enabling rule"
        Enable-NetFirewallRule -DisplayName "File and Printer Sharing (Echo Request - ICMPv4-In)"
       # netsh advfirewall firewall add rule name="ICMP Allow incoming V4 echo request" protocol=icmpv4:8,any dir=in action=allow 
    }
        'No' {Write-Host "Rule enable skipped" -ForegroundColor 'Red'}
    }
}

#add firewall to allow inbound RDP

Write-Host "Checking if inbound RDP firewall rule enabled"
$ruleenabled = get-netfirewallrule -DisplayName "Remote Desktop - User Mode (TCP-In)"
if($ruleenabled.Enabled -eq 'True' )
{
    Write-Host "Rule is already enabled"
}
Else
{
    Add-Type -AssemblyName PresentationCore,PresentationFramework	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm firewall change"
    $Messageboxbody = "Allow inbound RDP rule?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

    switch  ($msgBoxInput) {
    'Yes' {
        Write-Host "Enabling rule"
        Enable-NetFirewallRule -DisplayName "Remote Desktop - User Mode (TCP-In)"
        Enable-NetFirewallRule -DisplayName "Remote Desktop - User Mode (UDP-In)" 
    }
        'No' {Write-Host "Rule enable skipped" -ForegroundColor 'Red'}
    }
}

#logic to detect if DC

Write-Host "Checking if DC..."
$DomainRole = Get-WmiObject -Class Win32_ComputerSystem |
    Select-Object -ExpandProperty DomainRole

if( $DomainRole -match '4|5' ){
 Write-Host "DC Detected" -ForegroundColor 'Cyan'
 
# import AD module
Write-Host "Importing AD module"
Import-module ActiveDirectory

# list domain, enterprise, and schema admins along with current enabled users
Write-Host "Creating user lists as CSV and TXT files..."

# list domain admins
$groupname = "Domain Admins"
$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object Name, SamAccountName, UserPrincipalName, Enabled }
$Output | Export-Csv -Path ($outpath + $domainadmin + ".csv") -NoTypeInformation
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object SamAccountName}
$Output |Out-File -FilePath ($outpath + $domainadmin + ".txt")

# list Enterprise Admins
$groupname = "Enterprise Admins"
$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object Name, SamAccountName, UserPrincipalName, Enabled }
$Output | Export-Csv -Path ($outpath + $entadmin + ".csv") -NoTypeInformation
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object SamAccountName}
$Output |Out-File -FilePath ($outpath + $entadmin + ".txt")

# list Schema Admins
$groupname = "Schema Admins"
$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object Name, SamAccountName, UserPrincipalName, Enabled }
$Output | Export-Csv -Path ($outpath + $schemaadmin + ".csv") -NoTypeInformation
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object SamAccountName}
$Output |Out-File -FilePath ($outpath + $schemaadmin + ".txt")

# list Domain users
$groupname = "Domain Users"
$users = Get-ADGroupMember -Identity $groupname | Where-Object {$_.objectclass -eq "user"}
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers -Properties "LastLogonDate"| Where-Object {$_.enabled -eq $true} | Select-Object Name, SamAccountName, UserPrincipalName, LastLogonDate, Enabled }
$Output | Export-Csv -Path ($outpath + $userlist + ".csv") -NoTypeInformation
$Output = foreach ($activeusers in $users) { Get-ADUser -Identity $activeusers | Where-Object {$_.enabled -eq $true} | Select-Object UserPrincipalName}
$Output |Out-File -FilePath ($outpath + $userlist + ".txt")

# check domain and forest level
Write-Host "Checking AD levels. Make sure to review this" -ForegroundColor 'Red'

get-addomain | format-list domainmode | Out-File -FilePath ($outpath + $adlevel)
get-adforest | format-list forestmode | Out-File -FilePath ($outpath + $adlevel) -Append

#Check if AD is on DFSR
Write-Host "Checking if AD is on DFSR"
dfsrmig.exe /GetMigrationState | Out-File -FilePath ($outpath + "AD_DFSR.txt")
$addfsr = dfsrmig.exe /GetMigrationState
If ($addfsr -like '*Eliminated*')
    {
    Write-Host "AD is on DFSR replication" -ForegroundColor 'Green'
    }
Else 
    {
    Write-Host "AD is not on DFSR replication. Please plan to correct this." -ForegroundColor 'Red'
    }

#list servers in AD
Write-Host "Creating Server list, please review for old servers to be removed from AD"
Get-ADComputer -Filter  {OperatingSystem -Like '*SERVER*' } -Properties lastlogondate,operatingsystem |Select-Object name,lastlogondate,operatingsystem | Export-Csv -Path ($outpath + "servers.csv") -NoTypeInformation

# run dcdiag and output
Write-Host "Running DcDiag, this may take a couple of mins..."

dcdiag /e | Out-File -FilePath ($outpath + $dcdiag)

Write-Host "DCDiag complete. Please make sure to check for any issues which need investigating"

#run repadmin - these will only give usefull output if more than 1 DC
Write-Host "Checking AD Replication..."

repadmin /showreps | Out-File -FilePath ($outpath + $repadmin)
repadmin /replsum | Out-File -FilePath ($outpath + $repadmin) -Append

#list out all subnets in AD
Write-Host "Listing all subnets in AD"

	## Get a list of all domain controllers in the forest
	$DcList = (Get-ADForest).Domains | ForEach-Object { Get-ADDomainController -Discover -DomainName $_ } | ForEach-Object { Get-ADDomainController -Server $_.Name -filter * } | Select-Object Site, Name, Domain

	## Get all replication subnets from Sites & Services
	$Subnets = Get-ADReplicationSubnet -filter * -Properties * | Select-Object Name, Site, Location, Description

	## Create an empty array to build the subnet list
	$ResultsArray = @()

	## Loop through all subnets and build the list
	ForEach ($Subnet in $Subnets) {

		$SiteName = ""
		If ($null -ne $Subnet.Site) { $SiteName = $Subnet.Site.Split(',')[0].Trim('CN=') }

		$DcInSite = $False
		If ($DcList.Site -Contains $SiteName) { $DcInSite = $True }

		$RA = New-Object PSObject
		$RA | Add-Member -type NoteProperty -name "Subnet"   -Value $Subnet.Name
		$RA | Add-Member -type NoteProperty -name "SiteName" -Value $SiteName
		$RA | Add-Member -type NoteProperty -name "DcInSite" -Value $DcInSite
		$RA | Add-Member -type NoteProperty -name "SiteLoc"  -Value $Subnet.Location
		$RA | Add-Member -type NoteProperty -name "SiteDesc" -Value $Subnet.Description

		$ResultsArray += $RA

	}

	## Export the array as a CSV file
	$ResultsArray | Sort-Object Subnet | Export-Csv -Path ($outpath + "subnets.csv") -NoTypeInformation

#checks for the certlog folder and cleans up if found
Write-Host "Checking for certlog..."

If((test-path c:\windows\system32\certlog))
{
      Write-Host "certlog found - stopping AD CS and cleaning up"
      Get-Service -Name "Active Directory Certificate Services" | Stop-Service
      Get-ChildItem -Path c:\windows\system32\certlog -Include *.log -File -Recurse -Force | ForEach-Object { $_.Delete()}
      Get-ChildItem -Path c:\windows\system32\certlog -Include edb.chk -File -Recurse -Force | ForEach-Object { $_.Delete()}
      Write-Host "Starting AD CS"
      Get-Service -Name "Active Directory Certificate Services" | Start-Service
}
Else {Write-Host "certlog not found"}

Write-Host "Checking AD Recycle Bin..."

# Get local domain name and format for use in DC=domain,DC=com LDAP format
$LDAPDomainString = ""
$domainName = (Get-WmiObject Win32_ComputerSystem).Domain

foreach ($strDomainPart in ($domainName).split("{.}")) {
    $LDAPDomainString += "DC=$strDomainPart,"
}

# Replace the trailing ","
$LDAPDomainString = $LDAPDomainString -replace ".$"

# Get the value for enabled Scopes
$RecycleBinEnabledScopes = Get-ADOptionalFeature -Filter 'name -like "Recycle Bin Feature"' | Select-Object -ExpandProperty "EnabledScopes"

# Check if there are no enabled scopes, otherwise return Successful and do not run
If (!$RecycleBinEnabledScopes) {

    # Enable AD Recycle Bin Feature for domain
    Write-Host "enabling AD Recycle bin for" $domainName -ForegroundColor 'Red'
	(Enable-ADOptionalFeature -Identity "CN=Recycle Bin Feature,CN=Optional Features,CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration,$LDAPDomainString" -Scope ForestOrConfigurationSet -Target "$domainName" -Confirm:$false)
	
} 
Else {
   
    Write-Host "AD Recycle bin already enabled" -ForegroundColor 'Green'
}

#Check for and import GPOs

Write-Host "Remove old GPOs which need replacing"

If((Get-GPO -Name "Pyranet - RMM"))
{
    Remove-GPO -Name "Pyranet - RMM"
}
If((Get-GPO -Name "WavenetCIT - RMM"))
{
    Remove-GPO -Name "WavenetCIT - RMM"
}
If((Get-GPO -Name "SSL Cipher Suites"))
{
    Remove-GPO -Name "SSL Cipher Suites"
}
If((Get-GPO -Name "MS15-011 - HardenedPaths GPO"))
{
    Remove-GPO -Name "MS15-011 - HardenedPaths GPO"
}

Write-Host "Checking for Hardened Paths GPO"
If(!(Get-GPO -Name "WavenetCIT - MS15-011"))
{
Write-Host "GPO Does not exist, importing" -ForegroundColor 'Red'
    If(!(Test-Path $importfolder))
    {
    Write-Host "Error - GPO import files not found. Please correct and re-run script" -ForegroundColor 'Red'
    }
    Else
    {
        $Root = [ADSI]"LDAP://RootDSE"
        $Domain = $Root.Get("rootDomainNamingContext")

        Import-GPO -Path $PSScriptRoot -BackupGpoName "MS15-011 - HardenedPaths GPO" -TargetName "WavenetCIT - MS15-011" -CreateIfNeeded |Out-Null
        New-GPLink -name "WavenetCIT - MS15-011" -LinkEnabled Yes -Target $Domain | Out-Null
        Write-Host "GPO Imported" -ForegroundColor 'Green'
    }
}
Else
{
Write-Host "GPO found" -ForegroundColor 'Green'
}

Write-Host "Checking for Bitrlocker GPO"
If(!(Get-GPO -Name "WavenetCIT - StoreBitlockerInAD"))
{
Write-Host "GPO Does not exist, importing" -ForegroundColor 'Red'
    If(!(Test-Path $importfolder))
    {
    Write-Host "Error - GPO import files not found. Please correct and re-run script" -ForegroundColor 'Red'
    }
    Else
    {
        $Root = [ADSI]"LDAP://RootDSE"
        $Domain = $Root.Get("rootDomainNamingContext")

        Import-GPO -Path $PSScriptRoot -BackupGpoName "WavenetCIT - StoreBitlockerInAD" -TargetName "WavenetCIT - StoreBitlockerInAD" -CreateIfNeeded |Out-Null
        New-GPLink -name "WavenetCIT - StoreBitlockerInAD" -LinkEnabled Yes -Target $Domain | Out-Null
        Write-Host "GPO Imported" -ForegroundColor 'Green'
    }
}
Else
{
Write-Host "Bitlocker GPO found" -ForegroundColor 'Green'
}

Write-Host "Checking for DisableFastStartup GPO"
If(!(Get-GPO -Name "DisableFastStartup"))
{
Write-Host "GPO Does not exist, importing" -ForegroundColor 'Red'
    If(!(Test-Path $importfolder))
    {
    Write-Host "Error - GPO import files not found. Please correct and re-run script" -ForegroundColor 'Red'
    }
    Else
    {
        $Root = [ADSI]"LDAP://RootDSE"
        $Domain = $Root.Get("rootDomainNamingContext")

        Import-GPO -Path $PSScriptRoot -BackupGpoName "DisableFastStartup" -TargetName "DisableFastStartup" -CreateIfNeeded |Out-Null
        New-GPLink -name "DisableFastStartup" -LinkEnabled Yes -Target $Domain | Out-Null
        Write-Host "GPO Imported" -ForegroundColor 'Green'
    }
}
Else
{
Write-Host "DisableFastStartup GPO found" -ForegroundColor 'Green'
}

# Block Win11

    Add-Type -AssemblyName PresentationCore,PresentationFramework
	
    $ButtonType = [System.Windows.MessageBoxButton]::YesNo
    $MessageboxTitle = "Confirm Win 11 block"
    $Messageboxbody = "Import Win 11 block GPO?"
    $MessageIcon = [System.Windows.MessageBoxImage]::Error
    $msgBoxInput =  [System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

  switch  ($msgBoxInput) {

  'Yes' {
	    Write-Host "Checking for BlockWindows11 GPO"
	    If(!(Get-GPO -Name "BlockWindows11"))
	        {
	        	Write-Host "GPO Does not exist, importing" -ForegroundColor 'Red'
		        If(!(Test-Path $importfolder))
		        {
		            Write-Host "Error - GPO import files not found. Please correct and re-run script" -ForegroundColor 'Red'
		        }
		        Else
	        	{
		        	$Root = [ADSI]"LDAP://RootDSE"
		        	$Domain = $Root.Get("rootDomainNamingContext")

		        	Import-GPO -Path $PSScriptRoot -BackupGpoName "BlockWindows11" -TargetName "BlockWindows11" -CreateIfNeeded |Out-Null
		        	New-GPLink -name "BlockWindows11" -LinkEnabled Yes -Target $Domain | Out-Null
		        	Write-Host "GPO Imported" -ForegroundColor 'Green'
	        	}
	        }
	    Else
	    {
		Write-Host "BlockWindows11 GPO found" -ForegroundColor 'Green'
	    }
     }
        'No' {Write-Host "Win 11 block skipped skipped"}

    }

# install bitlocker componants 

Install-WindowsFeature BitLocker -IncludeAllSubFeature -IncludeManagementTools

# disable old RMM user account

Disable-ADAccount -Identity MWService

# Get PDC Emulator for domain
$pdcemulatorname = (get-addomain).pdcemulator
$thisdcname = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname

# check if PDC Emulator and run approiate time settings
if ($pdcemulatorname -like $thisdcname )
{
Write-Host "This DC is running PDCEmulator, running appropriate time service reset..." -ForegroundColor 'Red'
net stop w32time 
w32tm /unregister 
w32tm /register 
net start w32time 
W32tm /config /manualpeerlist:"0.pool.ntp.org 1.pool.ntp.org 2.pool.ntp.org" /syncfromflags:manual /reliable:yes /update 
w32tm /resync /rediscover 
net stop w32time 
net start w32time 
}
Else
{
Write-Host "This is not running PDCEmulator, resetting time service to use AD..." -ForegroundColor 'Cyan'
net stop w32time | Out-Null
w32tm /unregister | Out-Null
w32tm /register | Out-Null
net start w32time  | Out-Null
w32tm /config /syncfromflags:domhier /update /reliable:no | Out-Null
w32tm /resync /rediscover | Out-Null
net stop w32time | Out-Null
net start w32time | Out-Null
}

}
 else{ 
 Write-Host "Not a DC - skipping AD tasks"
 
 #reset time service to user AD / defaults
Write-Host "Resetting Windows time service to use AD / Windows defaults"
Stop-Service w32time
w32tm /unregister
w32tm /register
Start-Service w32time
w32tm /resync /rediscover
 }

 # write out server s/n
 get-ciminstance win32_bios | format-list serialnumber
 get-ciminstance win32_bios | format-list serialnumber | Out-File -FilePath ($outpath + "serial.txt")

 # create zip file of all output files
 Write-Host "Doing some cleanup"
 $servername = $servername + "_"
 Start-Sleep -Second 10 #make sure all files written. Misses some if not here

 # date stamp file names
 Get-ChildItem -Path $outpath -Filter *.csv | ForEach-Object { Rename-Item -Path $_.FullName -NewName "$($_.DirectoryName)\$servername$($_.BaseName)_$stamp$($_.Extension)" -Force }
 Get-ChildItem -Path $outpath -Filter *.txt | ForEach-Object { Rename-Item -Path $_.FullName -NewName "$($_.DirectoryName)\$servername$($_.BaseName)_$stamp$($_.Extension)" -Force }
  
 Write-Host "Creating zip file..."
 Write-Host "Please be sure to check all output files for issues, and plan accordingly"
 Add-Type -assembly "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($outpath, $destination) 
Get-ChildItem -Path $outpath -Filter zz_output.zip | ForEach-Object { Rename-Item -Path $_.FullName -NewName "$($_.DirectoryName)\$servername$($_.BaseName)_$stamp$($_.Extension)" -Force }

Write-Host "Completed."